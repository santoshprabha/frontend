export enum CategoryType {
    "Home","Books", "Food",  "Drink","Electronics","Men","women","Kids"
}
